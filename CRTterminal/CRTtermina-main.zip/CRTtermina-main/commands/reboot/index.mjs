import { boot } from "../../util/screens.js";

const output = "Okay ;_;";

export { output };
export default () => boot();
