import { clear } from '../../util/screens.js';

export default clear;
