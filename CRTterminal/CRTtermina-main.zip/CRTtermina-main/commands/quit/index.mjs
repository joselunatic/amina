import { off } from "../../util/power.js";

const output = "Goodbye.";

export default () => {
	return off();
};
export { output };
