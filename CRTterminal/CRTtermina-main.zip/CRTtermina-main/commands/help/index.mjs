const output = [
	"Available commands:",
	"help, fallout, brogue, dino, hackerman, matrix, screensaver, text-editor, cowsay, fire, clear, logout, reboot, quit"
];

export { output };
