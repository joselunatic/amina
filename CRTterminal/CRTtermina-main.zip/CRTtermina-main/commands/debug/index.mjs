const output =
	"This line is exactly 80 characters long to test width of the screen...";

export { output };
